package lec04;

public class Dillo implements IAnimal {
    public int length;
    public boolean isDead;

    public Dillo(int len, boolean isD) {
        this.length = len;
        this.isDead = isD;
    }

    // determine whether dillo is long and dead
    public boolean canShelter() {
        return this.isDead && (this.length > 60);
    }

    // determine whether length between 12 and 24
    public boolean isNormalSize() {
        return this.length >= 12 && this.length <= 24;
    }
}
