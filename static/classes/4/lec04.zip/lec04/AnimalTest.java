package lec04;
import tester.*;

public class AnimalTest {
    public AnimalTest() {
    }

    Dillo babyDillo = new Dillo(8, false);
    Dillo adultDillo = new Dillo(24, false);
    Dillo hugeDillo = new Dillo(65, true);
    Boa meanBoa = new Boa("Slinky", 36, "nails");
    Boa thinBoa = new Boa("Slim", 24, "lettuce");
    Zoo farm1 = new Zoo(babyDillo, meanBoa);
    Zoo farm2 = new Zoo(new Boa("MrQ",35, "peanuts"), adultDillo);

    public void testCanShelter(Tester t) {
        // if you want to check that a value is true, you don't need an expected result
        t.checkExpect(!babyDillo.canShelter());
        t.checkExpect(babyDillo.canShelter(), false);
    }

    public void testHealthCheck(Tester t) {
        t.checkExpect(farm1.healthCheck(), "Failed");
        t.checkExpect(farm2.healthCheck(), "Passed");
    }

    public static void main(String[] args) {
        Tester.runReport(new AnimalTest(),false,false);
    }
}
