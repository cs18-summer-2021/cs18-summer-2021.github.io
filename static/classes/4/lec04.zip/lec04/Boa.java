package lec04;

public class Boa implements IAnimal {
    public String name;
    public Integer length;
    public String eats;

    public Boa(String name, Integer length, String eats) {
        this.name = name;
        this.length = length;
        this.eats = eats;
    }

    public boolean isNormalSize() {
        return this.length >= 30 && this.length <= 60;
    }
}

