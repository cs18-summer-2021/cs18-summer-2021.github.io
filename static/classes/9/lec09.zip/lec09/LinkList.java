package lec09;

public class LinkList implements IList {
    IListInternal start = new EmptyList();  // the actual list underneath

    LinkList(){}

    public boolean isEmpty() { return this.start.isEmpty(); }

    public LinkList addFirst(int newelt) {
        this.start = new NodeList(newelt, this.start);
        return this;
    }

    // add the newelt to the end of the list
    public LinkList addLast(int newelt) {
        if (this.isEmpty()) { // start field gets affected
            this.start = new NodeList(newelt, this.start);
        } else {
            this.start.addLast(newelt);
        }
        return this;
    }

    /**
     * Remove first occurrence of item in a list
     * @param elt -- the item to remove
     */
    public IList remEltOnce(int elt) {
        this.start = this.start.remEltOnce(elt);
        return this;
    }

    /**
     * Produce the number of elements in the list
     */
    public int length() { return this.start.length(); }

    /**
     * Get the first element of the list
     */
    public int head() {return this.start.head(); }

    @Override
    public String toString() {
        return "[" + this.start.toString() + "]";
    }
}