package lec15;

public class Main {
    public static void main(String[] args) {
        BankingService B = new BankingService();
        // setup initial data
        Customer kCust = new Customer("kathi", "cs18");
        Account kAcct = new Account(100465, kCust, 150);
        B.addCustomer(kCust);
        B.addAccount(kAcct);
        // start the system (with a login screen for a customer)
        B.loginScreen();
        // run some other methods to check whether system is working
        // (in a real system, these would be out in a testing class)
        kAcct.printBalance();
        B.withdraw(100465, 30);
        kAcct.printBalance();
    }
}
