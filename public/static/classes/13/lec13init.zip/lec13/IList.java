package lec13;

public interface IList<T> {
	public int size();
	public void addFirst(T elt);
	public void addLast(T elt);
	public boolean contains(T elt);
}
