package lec13;
import tester.*;

public class VoteTest {

	public void testCountEmpty(Tester t) {
		Votes v = new Votes();
		t.checkExpect(v.countVotesFor("Kathi"), 0);
	}
	
	public void testCountVotesCast(Tester t) {
		Votes v = new Votes();
		v.castVote("Bruno");
		v.castVote("Carberry");
		v.castVote("Carberry");	
		t.checkExpect(v.countVotesFor("Bruno"), 1);
		t.checkExpect(v.countVotesFor("Carberry"), 2);
		t.checkExpect(v.countVotesFor("Kathi"), 0);
	}
	
	public static void main(String[] args) {
		Tester.run(new VoteTest());
	}
}
