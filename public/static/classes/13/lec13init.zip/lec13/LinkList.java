package lec13;
import java.util.Iterator;

public class LinkList<T> implements IList<T> {
	Node start = null;
	Node end = null;
	int eltCount = 0;
	
	public LinkList() {}
	
	// ----------------------------------------------------------
	// The inner node class -- prevents use from outside LinkList
	class Node {
		T item;
		Node next;
		
		Node(T item, Node next) {
			this.item = item;
			this.next = next;
		}
	}

	// ------- the methods ----------------------------------------
	/*
	 * indicate whether the list is empty
	 */
	 boolean isEmpty() {
		 return ((this.start == null) && (this.end == null));
	 }
	
	 /* 
	  * @return the number of elements in the list
	  */
	public int size() { 
		return this.eltCount; 
	}
	
	/*
	 * adds an item to the front of the list
	 * @param elt - the element to add
	 */
	public void addFirst(T elt) {
		Node newN = new Node(elt, this.start);
		this.start = newN;
		if (this.end == null) {
			this.end = newN;
		}
		this.eltCount = this.eltCount + 1;
	}
	
	/*
	 * adds an item to the end of the list
	 * @param elt - the element to add
	 */
	public void addLast(T elt) {
		if (this.isEmpty()) {
			this.addFirst(elt);
		} else {
			Node newNode = new Node(elt, null);
			this.end.next = newNode;
			this.end = newNode;
			this.eltCount = this.eltCount + 1;
		}
	}
	
	/*
	 * determines whether an element is in the list
	 * @param elt - the element to search for in the list
	 * @return whether the element is in the list
	 */
	public boolean contains(T elt) {
		Node current = this.start;
		while (current != null) {
			if (current.item == elt) {
				return true;
			}
			current = current.next;
		}
		return false;
	}	
}

