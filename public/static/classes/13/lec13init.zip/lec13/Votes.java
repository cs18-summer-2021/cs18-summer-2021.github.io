package lec13;

public class Votes {
	// using the interface type lets us change which list
	// implementation we use as needs change
	IList<String> votes; 
	
	Votes() {
		// the constructor is where we pick which 
		// specific list implementation to use.
		// All other uses of votes are through the interface
		this.votes = new LinkList<String>();
	}
	
	/*
	 * record a vote for the given name
	 * @param forwho - the name being voted for
	 */
	public void castVote(String forwho) {
		this.votes.addFirst(forwho);
	}
	
	// we can't write countVoteFor using a while loop
	// over Nodes, because Nodes are not accessible
	// through the IList interface. Restricting ourselves
	// to the interface is what will let us change list
	// implementations later if need be.
	
	/*
	 * count votes received for the given name
	 * @param forwho - the name to look for
	 * @return number of votes for the given name
	 */
	public int countVotesFor(String forwho) {
		int count = 0;
		for(String name : votes) {
			if (name.equals(forwho)) {
				count = count + 1;
			}
		}
		return count;
	}
}
